
const INITIAL_STATE = {
    name: "Ghous"
}

const reducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case "UPDATE":
            return {
                ...state,
                name: action.name
            }
        default:
            return state
    }
}

export default reducer;