import { Link } from "react-router-dom";
import { useSelector, useDispatch } from 'react-redux'

function Home() {
    const store = useSelector(state => state);
    const dispatch = useDispatch();

    console.log("Home store=>", store)
    return (
        <div>
            <h1>Home</h1>
            <h2>{store.name}</h2>
            <button onClick={() => dispatch({ type: "UPDATE", name: "Ahmed" })}>UPDATE</button>
            <Link to="/about">About</Link>
        </div>
    )
}

export default Home;