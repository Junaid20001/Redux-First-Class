import { Link } from "react-router-dom";
import { useSelector } from 'react-redux'


function About() {
    const store = useSelector(state => state);

    console.log("About store=>", store)
    return (
        <div>
            <h1>About</h1>
            <Link to="/">Home</Link>
        </div>
    )
}

export default About;